/**
 * Stores the details and loyalty points of a cafe customer.
 *
 * @author John Michael Bacang
 * @version 1.0
 */
public class Customer {
    private String name;
    private boolean student;
    private int loyaltyPoints;

    /** Creates a guest customer who is not a student. */
    public Customer() {
        this("Guest", false);
    }

    /**
     * Creates a non-student customer.
     * @param name customer name
     */
    public Customer(String name) {
        this(name, false);
    }

    /**
     * Creates a customer with the supplied student status.
     * @param name customer name
     * @param student true if the customer is a student
     */
    public Customer(String name, boolean student) {
        this.name = name;
        this.student = student;
        this.loyaltyPoints = 0;
    }

    /**
     * Adds a specified number of loyalty points.
     * @param points points to add
     */
    public void addPoints(int points) {
        if (points > 0) {
            loyaltyPoints += points;
        }
    }

    /**
     * Adds one point for every 50 pesos spent.
     * @param amountSpent purchase amount
     */
    public void addPoints(double amountSpent) {
        if (amountSpent > 0) {
            loyaltyPoints += (int) (amountSpent / 50);
        }
    }

    /** @return customer name */
    public String getName() { return name; }

    /**
     * Changes the customer name.
     * @param name new customer name
     */
    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        } else {
            System.out.println("Error: customer name cannot be empty.");
        }
    }

    /** @return true if the customer is a student */
    public boolean isStudent() { return student; }

    /**
     * Changes the customer's student status.
     * @param student new student status
     */
    public void setStudent(boolean student) { this.student = student; }

    /** @return current loyalty points */
    public int getLoyaltyPoints() { return loyaltyPoints; }

    /**
     * Changes loyalty points, rejecting negative values.
     * @param loyaltyPoints new loyalty-point balance
     */
    public void setLoyaltyPoints(int loyaltyPoints) {
        if (loyaltyPoints < 0) {
            System.out.println("Error: loyalty points cannot be negative.");
        } else {
            this.loyaltyPoints = loyaltyPoints;
        }
    }
}
