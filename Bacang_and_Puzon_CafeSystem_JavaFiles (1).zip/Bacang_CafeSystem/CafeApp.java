/**
 * Runs the Campus Cafe Ordering System demonstration.
 *
 * @author John Michael Bacang
 * @version 1.0
 */
public class CafeApp {
    /**
     * Creates customers, menu items, and orders, then prints receipts.
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        // Create customers using different constructors.
        Customer ana = new Customer("Ana Reyes", true);
        Customer ben = new Customer("Ben Cruz");

        // Create menu items using parameterized constructors.
        Beverage latte = new Beverage("Iced Latte", 95, "B-01", "L");
        Pastry ensaymada = new Pastry("Ensaymada", 45, "P-01", true);
        Meal adobo = new Meal("Chicken Adobo", 110, "M-01", true, 1);
        Pastry cookie = new Pastry("Cookie", 30, "P-02", false);

        // Create first order and demonstrate the three-item limit.
        Order order1 = new Order("1001", ana);
        order1.addItem(latte);
        order1.addItem(ensaymada);
        order1.addItem(adobo);
        order1.addItem(cookie);
        order1.printReceipt();

        // Demonstrate a setter rejecting invalid data.
        System.out.println();
        Beverage hotChocolate = new Beverage();
        hotChocolate.setBasePrice(-5);
        hotChocolate.setName("Hot Chocolate");
        hotChocolate.setItemCode("B-02");
        hotChocolate.setBasePrice(80);
        hotChocolate.setSize("M");

        // Create a meal using the parameterized constructor.
        Meal tapa = new Meal("Beef Tapa", 130, "M-02", false, 0);

        // Create second order and apply a voucher.
        Order order2 = new Order("1002", ben);
        order2.addItem(hotChocolate);
        order2.addItem(tapa);
        order2.printReceipt(20);

        // Also demonstrate the default constructors for the subclasses.
        Pastry defaultPastry = new Pastry();
        Meal defaultMeal = new Meal();
        System.out.println();
        System.out.println("Default objects created: "
                + defaultPastry.getDescription() + ", "
                + defaultMeal.getDescription());
    }
}
