/**
 * Represents a baked item that may be warmed for an extra fee.
 *
 * @author John Michael Bacang
 * @version 1.0
 */
public class Pastry extends MenuItem {
    private boolean warmed;

    /** Creates a pastry that is not warmed. */
    public Pastry() {
        super();
        warmed = false;
    }

    /**
     * Creates a pastry with the supplied details.
     * @param name pastry name
     * @param basePrice starting price
     * @param itemCode pastry code
     * @param warmed true if the pastry is warmed
     */
    public Pastry(String name, double basePrice, String itemCode, boolean warmed) {
        super(name, basePrice, itemCode);
        this.warmed = warmed;
    }

    /**
     * Computes the pastry price.
     * @return base price plus 10 pesos when warmed
     */
    @Override
    public double computePrice() {
        double price = basePrice;
        // Add the warming fee only when warmed is true.
        if (warmed) {
            price += 10;
        }
        return price;
    }

    /**
     * Adds the warmed status to the parent description.
     * @return complete pastry description
     */
    @Override
    public String getDescription() {
        if (warmed) {
            return super.getDescription() + " (Warmed)";
        }
        return super.getDescription();
    }

    /** @return true if the pastry is warmed */
    public boolean isWarmed() { return warmed; }

    /**
     * Changes the warmed status.
     * @param warmed new warmed status
     */
    public void setWarmed(boolean warmed) { this.warmed = warmed; }
}
