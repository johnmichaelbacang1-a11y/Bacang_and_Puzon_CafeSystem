/**
 * Represents an order containing up to three menu items.
 *
 * @author John Michael Bacang
 * @version 1.0
 */
public class Order {
    private Customer customer;
    private MenuItem item1;
    private MenuItem item2;
    private MenuItem item3;
    private int itemCount;
    private String orderId;

    /**
     * Creates an order for a customer.
     * @param orderId order identification
     * @param customer customer placing the order
     */
    public Order(String orderId, Customer customer) {
        this.orderId = orderId;
        this.customer = customer;
        this.itemCount = 0;
    }

    /**
     * Adds an item to the first available slot.
     * @param item menu item to add
     * @return true if added; false if full or item is null
     */
    public boolean addItem(MenuItem item) {
        if (item == null) {
            return false;
        } else if (item1 == null) {
            item1 = item;
        } else if (item2 == null) {
            item2 = item;
        } else if (item3 == null) {
            item3 = item;
        } else {
            System.out.println("Order is full. Cannot add "
                    + item.getDescription() + ".");
            return false;
        }
        itemCount++;
        return true;
    }

    /**
     * Adds the prices of all items in the order.
     * @return subtotal before discounts
     */
    public double computeSubtotal() {
        double subtotal = 0.0;
        if (item1 != null) subtotal += item1.computePrice();
        if (item2 != null) subtotal += item2.computePrice();
        if (item3 != null) subtotal += item3.computePrice();
        return subtotal;
    }

    /**
     * Applies a 10 percent discount for student customers.
     * @return total after applicable student discount
     */
    public double computeTotal() {
        double subtotal = computeSubtotal();
        if (customer.isStudent()) {
            return subtotal * 0.90;
        } else {
            return subtotal;
        }
    }

    /**
     * Applies a voucher after the student discount.
     * @param voucher voucher amount to subtract
     * @return total, never lower than zero
     */
    public double computeTotal(double voucher) {
        double total = computeTotal() - voucher;
        if (total < 0) {
            total = 0;
        }
        return total;
    }

    /**
     * Prints the receipt and updates the customer's loyalty points.
     */
    public void printReceipt() {
        double subtotal = computeSubtotal();
        double total = computeTotal();
        double discount = subtotal - total;

        printHeading();
        printItem(item1);
        printItem(item2);
        printItem(item3);
        System.out.printf("Subtotal: %.2f%n", subtotal);
        if (customer.isStudent()) {
            System.out.printf("Student discount (10%%): -%.2f%n", discount);
        }
        System.out.printf("TOTAL: %.2f%n", total);
        customer.addPoints(total);
        System.out.println("Loyalty points: " + customer.getLoyaltyPoints());
    }

    /**
     * Prints a receipt with a voucher applied.
     * @param voucher voucher amount to subtract
     */
    public void printReceipt(double voucher) {
        double subtotal = computeSubtotal();
        double studentTotal = computeTotal();
        double discount = subtotal - studentTotal;
        double safeVoucher = Math.max(0, voucher);
        double total = computeTotal(safeVoucher);

        printHeading();
        printItem(item1);
        printItem(item2);
        printItem(item3);
        System.out.printf("Subtotal: %.2f%n", subtotal);
        if (customer.isStudent()) {
            System.out.printf("Student discount (10%%): -%.2f%n", discount);
        }
        System.out.printf("Voucher: -%.2f%n", safeVoucher);
        System.out.printf("TOTAL: %.2f%n", total);
        customer.addPoints(total);
        System.out.println("Loyalty points: " + customer.getLoyaltyPoints());
    }

    /** Prints the order number and customer name. */
    private void printHeading() {
        System.out.println("Order #" + orderId + " — " + customer.getName()
                + (customer.isStudent() ? " (Student)" : ""));
    }

    /**
     * Prints one item if its slot is occupied.
     * @param item menu item to print
     */
    private void printItem(MenuItem item) {
        if (item != null) {
            System.out.printf(" %s ............ %.2f%n",
                    item.getDescription(), item.computePrice());
        }
    }
}
