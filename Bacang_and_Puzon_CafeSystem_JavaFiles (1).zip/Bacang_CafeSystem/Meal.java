/**
 * Represents a rice meal that may be upsized and have extra sides.
 *
 * @author John Michael Bacang
 * @version 1.0
 */
public class Meal extends MenuItem {
    private boolean upsized;
    private int extraSides;

    /** Creates a regular meal with no extra sides. */
    public Meal() {
        super();
        upsized = false;
        extraSides = 0;
    }

    /**
     * Creates a meal with the supplied details.
     * @param name meal name
     * @param basePrice starting price
     * @param itemCode meal code
     * @param upsized true if upsized
     * @param extraSides number of extra sides
     */
    public Meal(String name, double basePrice, String itemCode,
                boolean upsized, int extraSides) {
        super(name, basePrice, itemCode);
        this.upsized = upsized;
        this.extraSides = 0;
        setExtraSides(extraSides);
    }

    /**
     * Computes the meal price.
     * @return base price plus upsize and extra-side fees
     */
    @Override
    public double computePrice() {
        double price = basePrice;
        // Upsizing adds 20 pesos.
        if (upsized) {
            price += 20;
        }
        // Each extra side adds 12 pesos.
        price += 12 * extraSides;
        return price;
    }

    /**
     * Describes the meal's size and number of extra sides.
     * @return complete meal description
     */
    @Override
    public String getDescription() {
        String status = upsized ? "Upsized" : "Regular";
        return super.getDescription() + " " + status + ", "
                + extraSides + (extraSides == 1 ? " side" : " sides");
    }

    /** @return true if the meal is upsized */
    public boolean isUpsized() { return upsized; }

    /**
     * Changes the upsize status.
     * @param upsized new upsize status
     */
    public void setUpsized(boolean upsized) { this.upsized = upsized; }

    /** @return number of extra sides */
    public int getExtraSides() { return extraSides; }

    /**
     * Sets the number of extra sides, rejecting negative values.
     * @param extraSides new number of extra sides
     */
    public void setExtraSides(int extraSides) {
        if (extraSides < 0) {
            System.out.println("Error: extra sides cannot be negative.");
        } else {
            this.extraSides = extraSides;
        }
    }
}
