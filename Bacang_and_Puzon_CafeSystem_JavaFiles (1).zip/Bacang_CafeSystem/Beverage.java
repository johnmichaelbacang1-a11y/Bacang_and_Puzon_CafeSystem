/**
 * Represents a beverage whose price depends on its size.
 *
 * @author John Michael Bacang
 * @version 1.0
 */
public class Beverage extends MenuItem {
    private String size;

    /** Creates a small beverage with default menu-item values. */
    public Beverage() {
        super();
        size = "S";
    }

    /**
     * Creates a beverage with the supplied details.
     * @param name beverage name
     * @param basePrice starting price
     * @param itemCode beverage code
     * @param size S, M, or L
     */
    public Beverage(String name, double basePrice, String itemCode, String size) {
        super(name, basePrice, itemCode);
        this.size = "S";
        setSize(size);
    }

    /**
     * Computes the price based on size.
     * @return base price plus the applicable size fee
     */
    @Override
    public double computePrice() {
        // Large adds 25 pesos; medium adds 15; small keeps the base price.
        if (size.equals("L")) {
            return basePrice + 25;
        } else if (size.equals("M")) {
            return basePrice + 15;
        } else {
            return basePrice;
        }
    }

    /**
     * Adds the beverage size to the parent description.
     * @return complete beverage description
     */
    @Override
    public String getDescription() {
        return super.getDescription() + " Size: " + size;
    }

    /** @return beverage size */
    public String getSize() { return size; }

    /**
     * Sets the beverage size if it is valid.
     * @param size S, M, or L
     */
    public void setSize(String size) {
        // Keep the previous value when the new size is invalid.
        if ("S".equals(size) || "M".equals(size) || "L".equals(size)) {
            this.size = size;
        } else {
            System.out.println("Invalid size. Use S, M, or L.");
        }
    }
}
