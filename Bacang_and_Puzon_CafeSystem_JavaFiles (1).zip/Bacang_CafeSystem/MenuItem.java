/**
 * Abstract parent class for all items sold in the campus cafe.
 *
 * @author John Michael Bacang
 * @version 1.0
 */
public abstract class MenuItem {
    protected String name;
    protected double basePrice;
    private String itemCode;

    /** Creates a menu item with default values. */
    public MenuItem() {
        this("Unnamed Item", 0.0, "N/A");
    }

    /**
     * Creates a menu item with the supplied details.
     * @param name item name
     * @param basePrice starting price in pesos
     * @param itemCode unique item code
     */
    public MenuItem(String name, double basePrice, String itemCode) {
        this.name = name;
        this.basePrice = 0.0;
        setBasePrice(basePrice);
        this.itemCode = itemCode;
    }

    /** Computes the final price; subclasses provide the pricing rule.
     * @return computed item price
     */
    public abstract double computePrice();

    /**
     * Returns the item's name and code.
     * @return item description
     */
    public String getDescription() {
        return name + " [" + itemCode + "]";
    }

    /** @return item name */
    public String getName() { return name; }

    /**
     * Changes the item name.
     * @param name new item name
     */
    public void setName(String name) {
        if (name != null && !name.trim().isEmpty()) {
            this.name = name;
        } else {
            System.out.println("Error: item name cannot be empty.");
        }
    }

    /** @return starting price */
    public double getBasePrice() { return basePrice; }

    /**
     * Changes the starting price, rejecting negative values.
     * @param basePrice new starting price
     */
    public void setBasePrice(double basePrice) {
        if (basePrice < 0) {
            System.out.println("Error: base price cannot be negative.");
        } else {
            this.basePrice = basePrice;
        }
    }

    /** @return item code */
    public String getItemCode() { return itemCode; }

    /**
     * Changes the item code.
     * @param itemCode new item code
     */
    public void setItemCode(String itemCode) {
        if (itemCode != null && !itemCode.trim().isEmpty()) {
            this.itemCode = itemCode;
        } else {
            System.out.println("Error: item code cannot be empty.");
        }
    }
}
